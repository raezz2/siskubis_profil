        <div class="sidebar-panel bg-light">
            <div class="gull-brand pr-3 text-center mt-4 mb-2 d-flex justify-content-center align-items-center"><img class="pl-3" src="{{ asset('theme/images/logo.png')}}" alt="alt" />
                <span class=" item-name text-20 text-primary font-weight-700">SISKUBIS</span>
                <div class="sidebar-compact-switch ml-auto"><span style="background:#fff"></span></div>
            </div>
            <!--  user -->
            <div class="scroll-nav ps ps--active-y" data-perfect-scrollbar="data-perfect-scrollbar" data-suppress-scroll-x="true">
                <div class="side-nav">
                    <div class="main-menu">
                        <ul class="metismenu" id="menu">
                            <li class="Ul_li--hover"><a class="active" href="/user"><i class="i-Bar-Chart text-20 mr-2 "></i><span class="item-name text-15 ">Dashboard</span></a>
                                
                            </li>

                            <li class="Ul_li--hover"><a class="has-arrow" href="#"><i class="i-Computer-Secure text-20 mr-2 "></i><span class="item-name text-15 ">Keuangan</span></a>
                                <ul class="mm-collapse">
                                    <li class="item-name"><a href="widget-card.html"><i class="nav-icon i-Receipt-4"></i><span class="item-name">widget card</span></a></li>
                                    <li class="item-name"><a href="widgets-statistics.html"><i class="nav-icon i-Receipt-4"></i><span class="item-name">widget statistics</span></a></li>
                                    <li class="item-name"><a href="widget-list.html"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Widget List</span></a></li>
                                    <li class="item-name"><a href="widget-app.html"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Widget App </span></a></li>
                                    <li class="item-name"><a href="weather-card.html"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Weather App </span></a></li>
                                </ul>
                            </li>
                            <li class="Ul_li--hover"><a class="has-arrow" href="#"><i class="i-File-Horizontal-Text text-20 mr-2 text-muted"></i><span class="item-name text-15 text-muted">Persuratan</span></a>
							<ul class="mm-collapse">
                                    <li class="item-name"><a href="/user/suratmasuk"><i class="nav-icon i-Error-404-Window"></i><span class="item-name">Surat Masuk</span></a></li>
                                    <li class="item-name"><a href="/user/suratkeluar"><i class="nav-icon i-Male"></i><span class="item-name">Surat Keluar</span></a></li>
                                </ul>
							</li>
                            <li class="Ul_li--hover"><a class="" href="/user/pengumuman"><i class="i-File-Horizontal-Text text-20 mr-2 "></i><span class="item-name text-15 text">Pengumuman</span></a>
                            </li>

                        </ul>

                    </div>
                </div>
                <div class="ps__rail-x" style="left: 0px; bottom: 0px;">
                    <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div>
                </div>
                <div class="ps__rail-y" style="top: 0px; height: 404px; right: 0px;">
                    <div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 325px;"></div>
                </div>
                <div class="ps__rail-x" style="left: 0px; bottom: 0px;">
                    <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div>
                </div>
                <div class="ps__rail-y" style="top: 0px; height: 404px; right: 0px;">
                    <div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 325px;"></div>
                </div>
            </div>
            <!--  side-nav-close -->
        </div>