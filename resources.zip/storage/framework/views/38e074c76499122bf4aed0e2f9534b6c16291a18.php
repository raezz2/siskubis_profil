<!DOCTYPE html>
<html lang="en" dir="">

<head>

	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width,initial-scale=1" />
	<meta http-equiv="X-UA-Compatible" content="ie=edge" />
	<title>Dashboard SISKUBIS</title>
	<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet" />
	<link href="<?php echo e(asset('theme/css/themes/lite-purple.css')); ?>" rel="stylesheet" />
	<link href="<?php echo e(asset('theme/css/plugins/perfect-scrollbar.css')); ?>" rel="stylesheet" />
	<link rel="stylesheet" href="<?php echo e(asset('theme/css/plugins/fontawesome-5.css')); ?>" />
	<link href="<?php echo e(asset('theme/css/plugins/metisMenu.min.css')); ?>" rel="stylesheet" />
	<?php echo $__env->yieldContent('css'); ?>
	<?php echo \Livewire\Livewire::styles(); ?>

</head>

<body class="text-left">
	<?php if(auth()->guard()->guest()): ?>
	<div class="app-admin-wrap">
		<?php else: ?>
		<div class="app-admin-wrap layout-sidebar-vertical sidebar-full">
			<?php if (Auth::check() && Auth::user()->hasRole('admin')): ?>
			<?php echo $__env->make('admin.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endif; ?>
			<?php if (Auth::check() && Auth::user()->hasRole('inkubator')): ?>
			<?php echo $__env->make('inkubator.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endif; ?>
			<?php if (Auth::check() && Auth::user()->hasRole('mentor')): ?>
			<?php echo $__env->make('mentor.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endif; ?>
			<?php if (Auth::check() && Auth::user()->hasRole('tenant')): ?>
			<?php echo $__env->make('tenant.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endif; ?>
			<?php if (Auth::check() && Auth::user()->hasRole('user')): ?>
			<?php echo $__env->make('user.sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php endif; ?>
			<?php endif; ?>
			<div class="switch-overlay" style="display:none"></div>
			<div class="main-content-wrap mobile-menu-content bg-off-white m-0">
				<?php if(auth()->guard()->check()): ?>
				<?php if (Auth::check() && Auth::user()->hasRole('admin')): ?>
				<?php echo $__env->make('admin.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>
				<?php if (Auth::check() && Auth::user()->hasRole('inkubator')): ?>
				<?php echo $__env->make('inkubator.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>
				<?php if (Auth::check() && Auth::user()->hasRole('mentor')): ?>
				<?php echo $__env->make('mentor.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>
				<?php if (Auth::check() && Auth::user()->hasRole('tenant')): ?>
				<?php echo $__env->make('tenant.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>
				<?php if (Auth::check() && Auth::user()->hasRole('user')): ?>
				<?php echo $__env->make('user.header.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>
				<?php endif; ?>
				<!-- ============ Body content start ============= -->
				<div class="main-content pt-4">
					<?php echo $__env->yieldContent('breadcrumb'); ?>
					<?php echo $__env->yieldContent('content'); ?>
				</div>
				<div class="sidebar-overlay open"></div><!-- Footer Start -->
				<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<!-- fotter end -->
			</div>
		</div>
		<script src="<?php echo e(asset('theme/js/plugins/jquery-3.3.1.min.js')); ?>"></script>
		<script src="<?php echo e(asset('theme/js/plugins/bootstrap.bundle.min.js')); ?>"></script>
		<script src="<?php echo e(asset('theme/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
		<script src="<?php echo e(asset('theme/js/scripts/tooltip.script.min.js')); ?>"></script>
		<script src="<?php echo e(asset('theme/js/scripts/script.min.js')); ?>"></script>
		<script src="<?php echo e(asset('theme/js/scripts/script_2.min.js')); ?>"></script>
		<script src="<?php echo e(asset('theme/js/scripts/sidebar.large.script.min.js')); ?>"></script>
		<script src="<?php echo e(asset('theme/js/plugins/feather.min.js')); ?>"></script>
		<script src="<?php echo e(asset('theme/js/plugins/metisMenu.min.js')); ?>"></script>
		<script src="<?php echo e(asset('theme/js/scripts/layout-sidebar-vertical.min.js')); ?>"></script>
		<?php echo $__env->yieldContent('js'); ?>

		<script>
			$('.switch-overlay').on('click', function() {
				$(this).hide();
			});
			$(document).on('click', '.menu-toggle', function() {
				$('.switch-overlay').show();
			});
		</script>
		<?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>

<?php /**PATH C:\xampp\htdocs\siskubis\mastering\master\resources\views/layouts/app.blade.php ENDPATH**/ ?>