<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong>
        There are some problems with your input.<br/><br/>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div> 
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success mt-2" role="alert"><strong class="text-capitalize">Success!</strong> <?php echo e(session('success')); ?>

        <button class="close" type="button" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert"><strong class="text-capitalize">Danger!</strong> <?php echo e(session('error')); ?>

        <button class="close" type="button" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    </div>
<?php endif; ?>




<?php /**PATH C:\xampp\htdocs\siskubis\mastering\master\resources\views/layouts/alert.blade.php ENDPATH**/ ?>