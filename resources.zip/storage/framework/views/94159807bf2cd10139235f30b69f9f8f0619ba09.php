

<?php $__env->startSection('content'); ?>
<div class="main-content pt-4">
    <div class="breadcrumb">
        <h1>Persuratan</h1>
        <ul>
            <li><a href="href">Form</a></li>
            <li>Persuratan</li>
        </ul>
    </div>
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Tambah Surat</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card card-primary">
            <!-- /.card-header -->
            <div class="card-body">
              <div id="exaple2_wrapper" class="dataTables_wrapper dt-bootstrap4">
                <div class="row">
                  <div class="col-sm-12 col-md-6"></div>
                  <div class="col-sm-12 col-md-6"></div>
                </div>
                <div class="row">
                <div class="col-sm-12">
                  <form action="<?php echo e(url('kirimsurat')); ?>" method="post"  enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo $__env->make('layouts.alert', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="nama">Judul</label>
                          <input type="text" name="judul" class="form-control" placeholder="Judul">
                        </div>
                      </div>
                      <div class="col-sm-6">
                      <div class="form-group">
                          <label for="picker1">Kepada</label>
                          <select class="form-control" name="kepada">
                          <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($u->inkubator_id == Auth::user()->inkubator_id): ?>
                              <option value="<?php echo e($u->id); ?>"><?php echo e($u->email); ?></option>
                              <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          </div>
                      </div>

                      <div class="col-sm-6">
                      <div class="form-group">
                          <label for="picker1">Kategori</label>
                          <select class="form-control" name="priority">
                          <?php $__currentLoopData = $priority; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          </div>
                      </div>
                      <div class="col-sm-12">
                        <label for="alamat">Buat Surat</label>
                            <div class="input-group" >
                              <div class="input-group-prepend">
                              <textarea name="perihal" class="form-control" aria-label="With textarea " id="perihal"></textarea>
                              </div>
                            </div>
                          </div>
                        <div class="col-sm-3">
                        <div class="form-group">
                          <label for="file">File</label>
                          <div class="custom-file">
                            <input type="file" class="custom-file-input" id="exampleInputFile" name="file">
                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                          </div>
                        </div>
                        </div>
                        
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button class="btn btn-success" type="submit">Kirim</button>
                      <button type="reset" class="btn btn-danger" data-dismiss="modal" aria-hidden="true">Reset</button>
                    </div>
                  </form>
                </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->


          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      </div>
      <!-- /.row -->
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('theme/css/plugins/datatables.min.css')); ?>" />
  <!-- Asset Alert iziToast -->
	<link rel="stylesheet" href="<?php echo e(asset('izitoast/dist/css/iziToast.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(asset('theme/js/plugins/datatables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('theme/js/scripts/contact-list-table.min.js')); ?>"></script>
  <script src="<?php echo e(asset('theme/js/scripts/datatables.script.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/plugins/datatables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('theme/js/scripts/tooltip.script.min.js')); ?>"></script>

    <!-- Asset Alert iziToast -->
	<script src="<?php echo e(asset('izitoast/dist/js/iziToast.min.js')); ?>" type="text/javascript"></script>
    <script>
        $('#masuk').DataTable({
			responsive:true,
		});
		
		$('#keluar').DataTable({
			responsive:true,
		});
    </script>
    <script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
    <script>
      CKEDITOR.replace( 'perihal' );
    </script>
    
    <script>
      <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
      iziToast.error({
        title: 'Error',
        message: '<?php echo e($error); ?>',
        position: 'topRight',
        
      });
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siskubis\mastering\master\resources\views/surat/form.blade.php ENDPATH**/ ?>