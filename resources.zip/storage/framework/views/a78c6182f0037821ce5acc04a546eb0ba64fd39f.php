
<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-xl-8 col-lg-8">
		<div class="card">
			<div class="card-body">
				<small><?php echo e($berita->created_at->format('d M Y | h:i')); ?></small>
				<h1 class="card-title text-danger font-weight-bold">
					<?php echo e($berita->tittle); ?>

				</h1>
				<small><?php echo e($berita->profil_user->nama); ?> - <b>SISKUBIS</b></small>
				<img src="<?php echo e(asset('storage/berita/' . $berita->foto)); ?>" alt="<?php echo e($berita->slug); ?>" class="w-100" height="350px">
				<p class="text-justify"><?php echo $berita->berita; ?></p>
			</div>
		</div>
		<div class="card">
			<div class="card-body">
				<div class="card-title"><h6><?php echo e($total_komentar); ?> Responses</h6></div>
				<?php $__empty_1 = true; $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="row">
					<div class="col-md-2">
						<figure>
							<img src="<?php echo e(asset('assets/images/images2.jpg')); ?>" style="width: 65px; height: 65px;" class="rounded-circle">
						</figure>
					</div>
					<div class="col-md-10">
						<h5 class="heading"><?php echo e($row->name); ?></h5>
						<span><small class="text-mute"><?php echo e(\Carbon\Carbon::parse($row->created_at)->diffForHumans()); ?></small></span>
						<p><?php echo e($row->komentar); ?></p>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<p>Belum Ada Komentar</p>
				<?php endif; ?>
				<br><br>
				<form action="<?php echo e(route('inkubator.komentarBerita')); ?>" method="post" class="row">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" name="id" value="id" class="form-control">
					<input type="hidden" name="berita_id" value="<?php echo e($berita->id); ?>" class="form-control">
					<div class="col-md-12">
						<h3 class="title">Leave Your Response</h3>
					</div>
					<div class="form-group col-md-12" hidden>
						<label for="name">Nama</label>
						<input type="text" id="name" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
					</div>
					<div class="form-group col-md-12">
						<textarea class="form-control" name="komentar" placeholder="Write your response ..."></textarea>
					</div>
					<div class="form-group col-md-12">
						<button class="btn btn-primary">Send Response</button>
					</div>
				</form>
			</div>
		</div>
	</div>
<div class="col-xl-4 col-lg-4">
<div class="card mb-4">
	<div class="card-body">
		<div class="card-title mb-0">Berita Umum</div>
	</div>
	<div class="ul-widget-app__comments">
		<!--  row-comments -->
		<?php $__empty_1 = true; $__currentLoopData = $umum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<div class="ul-widget-app__row-comments">
			<div class="ul-widget-app__profile-pic p-3"><img class="profile-picture avatar-lg" src="<?php echo e(asset('storage/berita/' . $row->foto)); ?>" alt="alt" /></div>
			<div class="ul-widget-app__comment">
				<div class="ul-widget-app__profile-title">
					<a class="ul-widget4__title" href="<?php echo e(route('inkubator.showBerita', $row->slug)); ?>"><?php echo e(Str::limit($row->tittle, 40)); ?></a>
				</div>
				<div class="ul-widget-app__profile-status">
							<?php if($berita->publish == 1): ?>
								<span class="badge badge-pill badge-success p-1 mr-2">Publish</span>
							<?php else: ?>
								<span class="badge badge-pill badge-danger p-1 mr-2">Draft</span>
							<?php endif; ?>
					<span class="ul-widget-app__icons">
						<a href="href"><i class="i-Approved-Window text-mute"></i></a>
						<a href="href"><i class="i-Like text-mute"></i></a>
						<a href="href"><i class="i-Heart1 text-mute"></i></a>
					</span>
					<span class="text-mute"><?php echo e($row->created_at->format('d, M Y')); ?></span>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<p class="text-center">Tidak Ada Berita Umum</p>
		<?php endif; ?>
		</div>
		<ul class="pagination justify-content-center">
			<li class="page-item"></li>
		</ul>	
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siskubis\magang\berita\siskubis\resources\views/berita/showBerita.blade.php ENDPATH**/ ?>