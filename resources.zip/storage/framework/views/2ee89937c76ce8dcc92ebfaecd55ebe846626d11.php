
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('inkubator.updateBerita', $berita->id)); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
	<div class="row"> 
		<div class="col-xl-8 col-lg-8">
			<div class="card">
				<div class="card-header container-fluid">
	  				<div class="row">
						<div class="col-md-10">
		  					<h3>Berita</h3>
						</div>
	  				</div>
				</div>
				<div class="card-body">
					<div class="ul-widget__body">
						<div class="form-group">
	            			<label>Judul :</label>
	            			<div class="input-group">
	                			<input type="text" class="form-control" name="tittle" value="<?php echo e($berita->tittle); ?>" required>
	            			</div>
						</div>
						<div class="form-group">
							<label for="desc">Isi Berita :</label>
							<textarea name="berita" id="berita" class="form-control" required><?php echo e($berita->berita); ?></textarea>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-xl-4 col-lg-4">
			<div class="card mb-4">
				<div class="card-header container-fluid">
					<h3>Lainnya</h3>
				</div>	
				<div class="card-body">
					<div class="ul-widget__body">
						<div class="form-group">
                            <label>Kategori :</label>
                            <div class="input-group">
                                <select name="berita_category_id" class="form-control custom-select" required>
                                 	<option value="">Pilih</option>
                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->id); ?>" <?php echo e($berita->berita_category_id == $row->id ? 'selected':''); ?>><?php echo e($row->category); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Status :</label>
                            <div class="input-group">
                                <select name="publish" class="form-control custom-select" required>
                                 	<option value="" disabled>Pilih</option>
                                 	<?php if($berita->publish == 1): ?>
                                 		<option value="1" checked>Publish</option>
                                 		<option value="0">Draft</option>
                                 	<?php else: ?>
                                 		<option value="1">Publish</option>
                                 		<option value="0" checked>Draft</option>
                                 	<?php endif; ?>
                                </select>
                            </div>
                        </div>
						<div class="form-group">
							<label>Penulis :</label>
	           				<div class="input-group">
								<select name="author_id" class="form-control custom-select" required>
                                 	<option value="">Pilih</option>
                                    <?php $__currentLoopData = $penulis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->id); ?>" <?php echo e($berita->author_id == $row->id ? 'selected':''); ?>><?php echo e($row->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
	           				</div>
						</div>
						<div class="form-group" hidden>
							<label>View :</label>
	           				<div class="input-group">
								<input type="text" class="form-control" name="views" value="<?php echo e($berita->views); ?>" required>
	           				</div>
						</div>
                        <div class="form-group">
                            <label>Dapat dibaca oleh :</label>
                            <div class="input-group">
                                <select name="inkubator_id" class="form-control" required>
                                 	<option value="" disabled>Pilih</option>
                                 	<option value="0">Umum / Semua orang</option>
                                    <?php $__currentLoopData = $inkubator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($row->id); ?>" <?php echo e($berita->inkubutor_id == $row->id ? 'selected':''); ?>><?php echo e($row->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
						<div class="form-group">
							<label for="foto">Foto</label><br>
							<img src="<?php echo e(asset('storage/berita/' . $berita->foto)); ?>" width="100px" height="100px" alt="<?php echo e($berita->tittle); ?>"><hr>
                            <input type="file" name="foto"><br>
                            <p><strong>Biarkan kosong jika tidak ingin mengganti gambar</strong></p>
		        		</div>
						<div class="form-group">
							<button class="btn btn-primary">Update</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</form>

<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script>
	CKEDITOR.replace( 'berita' );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siskubis\magang\berita\siskubis\resources\views/berita/formEditBerita.blade.php ENDPATH**/ ?>