
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="display table" id="ul-contact-list" style="width:100%">
                    <tbody>
                        <?php $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- <iframe src="/img/pengumuman/<?php echo e($p->foto); ?>" class="dokumen" alt="dokumen" style="width:600px;height:700px;border:none;"></iframe> -->
                        <center>
                            <h3><?php echo e($p->title); ?></h3>
                        </center>
                        <p style="text-align: center;">Diposkan pada <?php echo e(date('d F Y', strtotime($p->created_at))); ?>

                        </p>
                        <br>
                        <br>
                        <p style="text-align:justify; text-indent: 0.5in;"><?php echo $p->pengumuman; ?></p>
                        <center><object data="/img/pengumuman/<?php echo e($p->foto); ?>" width="700" height="500"></object></center>
                        <div style="clear:both;"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </div>
            </div>
        </div>
    </div>
</div>
</div><!-- end of main-content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('theme/css/plugins/datatables.min.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('theme/js/plugins/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/scripts/contact-list-table.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/scripts/datatables.script.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/plugins/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/scripts/tooltip.script.min.js')); ?>"></script>
<!-- <script>
    $('#ul-contact-list').DataTable({
        responsive: true,
        order: [
            [2, 'DESC']
        ]
    });
</script> -->
<?php $__env->stopSection(); ?>
<!-- <table class="display table" id="ul-contact-list" style="width:100%">
    <tbody>
        <?php $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <center>
            <h4><?php echo e($p->title); ?></h4>
            <i><?php echo e($p->created_at); ?></i>
        </center>
        <br>
        <br>
        <div>
            <p style="text-align: justify; text-indent: 0.5in;"><?php echo e($p->pengumuman); ?>

            </p>
        </div>
        <div class="card-body">
            <h5 style="text-align: center; ">Lampiran</h5>
            <img class="center" alt="image" height="auto" width="100%" src="\img\pengumuman\<?php echo e($p->foto); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siskubis\mastering\master\resources\views/pengumuman/detail.blade.php ENDPATH**/ ?>