
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4><?php echo e($title); ?></h4>
            </div>
            <div class="card-body">
                <form action="/inkubator/pengumuman/update/<?php echo e($p->id); ?>" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>

                    <div class="form-group">
                        <input class="form-control" type="text" value="<?php echo e($p->title); ?>" placeholder="Title...." name="title">
                        <?php echo e($errors->first('title')); ?>

                    </div>
                    <div class="form-group">
                        <select class="form-control" name="kategori">
                            <option selected="" disabled="">Pilih Kategori</option>
                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>" <?php echo e(($p->priority_id == $k->id) ? 'selected' : ''); ?>><?php echo e($k->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo e($errors->first('kategori')); ?>

                    </div>
                    <div class="form-group">
                        <select class="form-control" name="inkubator">
                            <option selected="" disabled="">Pilih Inkubator</option>
                            <?php $__currentLoopData = $inkubator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($i->id); ?>" <?php echo e(($p->inkubator_id == $i->id) ? 'selected' : ''); ?>><?php echo e($i->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo e($errors->first('inkubator')); ?>

                    </div>
                    <div class="form-group">
                        <textarea class="form-control" rows="3" placeholder="Pengumuman ...." name="pengumuman" id="pengumuman"><?php echo e($p->pengumuman); ?></textarea>
                        <?php echo e($errors->first('pengumuman')); ?>

                    </div>
                    <div class="custom-file">
                        <label class="custom-file-label" for="exampleInputFile">Choose File</label>
                        <input type="file" class="custom-file-input" id="exampleInputFile" name="foto" multiple>
                        <object data="/img/pengumuman/<?php echo e($p->foto); ?>" width="400px"></object>
                        <input type="hidden" class="custom-file-input" id="hidden_image" name="hidden_image" value="<?php echo e($p->foto); ?>">
                        <?php echo e($errors->first('foto')); ?>

                    </div>
                    <div class="modal-footer">
                        <a href="/inkubator/pengumuman/"><button class="btn btn-secondary" type="button" data-dismiss="modal">Batal</button></a>
                        <button class="btn btn-primary" type="submit">
                            Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><!-- end of main-content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('theme/css/plugins/datatables.min.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('theme/js/plugins/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/scripts/contact-list-table.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/scripts/datatables.script.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/plugins/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('theme/js/scripts/tooltip.script.min.js')); ?>"></script>
<script>
    $('#ul-contact-list').DataTable({
        responsive: true,
        order: [
            [2, 'DESC']
        ]
    });
</script>
<script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('pengumuman');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siskubis\mastering\master\resources\views/pengumuman/pengumuman_edit.blade.php ENDPATH**/ ?>