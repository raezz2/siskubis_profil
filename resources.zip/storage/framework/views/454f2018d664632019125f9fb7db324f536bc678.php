
<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md">
      <div class="card">
        <div class="card-header">Buat Kategori Baru</div>
        <div class="card-body">
          <form action="<?php echo e(route('inkubator.kategori.create')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <label for="">Nama</label>
              <input type="text" class="form-control" name="category" placeholder="Enter Name Kategori">
            </div>
            <div class="form-group">
              <input type="submit" value="Simpan" class="btn btn-primary">
              <a href="<?php echo e(route('inkubator.berita')); ?>" class="btn btn-danger">Kembali</a>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div><br><br>
        <table class="table">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Kategori</th>
              <th>Pilihan</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $berita_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($no++); ?></td>
              <td><?php echo e($kategori->category); ?></td>
              <td>
                <a href="<?php echo e(route('inkubator.kategori.edit', $kategori)); ?>" class="btn btn-success btn-sm" style="float:left;">Edit</a>
                <form action="<?php echo e(route('inkubator.kategori.destroy',$kategori)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <input type="hidden" name="_method" value="DELETE">
                  <button type="submit" class="btn btn-danger btn-sm" style="margin-left:3px;">Hapus</button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siskubis\magang\berita\siskubis\resources\views/kategori/create.blade.php ENDPATH**/ ?>