

<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-xl-8 col-lg-8">
<div class="card">
<div class="card-header container-fluid">
  <div class="row">
	<div class="col-md-7">
	  <h3>Berita</h3>
    </div>
    <div class="col-md-3">
        <a href="<?php echo e(route('inkubator.kategori.create')); ?>"><button class="btn btn-primary custom-btn btn-sm ml-5">+ Tambah Kategori</button></a>
    </div>
	<div class="col-md-2">
	  <a href="<?php echo e(route('inkubator.formBerita')); ?>"><button class="btn btn-primary custom-btn btn-sm">+ Tambah Berita</button></a>
	</div>
  </div>
</div>
<div class="card-body">

<div class="row row-xs">
	<div class="col-md-4">
        <form action="<?php echo e(route('cariberita')); ?>" method="get" name="s" >
        <div class="input-group custom-search-form">
            <input type="text" class="form-control" name="search" placeholder="Search...">
        </div>
	</div>
	<div class="col-md-4 mt-3 mt-md-0">
            <input class="form-control" type="date" name="tgl" placeholder="Tanggal">
    </div>
	<div class="col-md-2 mt-3 mt-md-0">
	 <div class="btn-group">
        <select name="status" class="btn btn-danger btn-block dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            <option value="3">All</option>
            <option value="1">Publice</option>
            <option value="0">Draf</option>
        </select>
	  </div>
	</div>
	<div class="col-md-2 mt-3 mt-md-0">
		<button type="submit" class="btn btn-primary btn-block">Search</button>
	</div>
</form>
</div>
  <hr>
	<div class="ul-widget__body">
	<div class="ul-widget5">
		<?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="ul-widget5__item">
			<div class="ul-widget5__content">
				<div class="ul-widget5__pic"><img src="<?php echo e(asset('storage/berita/' . $b->foto)); ?>" alt="Third slide" /></div>
				<div class="ul-widget5__section">
					<a class="ul-widget4__title" href="<?php echo e(route('inkubator.showBerita', $b->slug)); ?>"><?php echo e(Str::limit($b->tittle, 40)); ?></a>
					<p class="ul-widget5__desc"><?php echo Str::limit($b->berita, 47); ?></p>
					<div class="ul-widget5__info">
						<span>Status : </span>
							<?php if($b->publish == 1): ?>
								<span class="badge badge-pill badge-success p-1 mr-2">Publish</span>
							<?php else: ?>
								<span class="badge badge-pill badge-danger p-1 mr-2">Draft</span>
							<?php endif; ?>
						<span>Author : </span><span class="text-primary"><?php echo e($b->profil_user->nama); ?></span><br>
						<span>Released : </span><span class="text-primary"><?php echo e($b->created_at->format('d, M Y')); ?></span>
					</div>
				</div>
			</div>
			<div class="ul-widget5__content">
				<div class="ul-widget5__stats"><span class="ul-widget5__sales"><?php echo e($b->views); ?> <i class="i-Eye"></i></span><span class="ul-widget5__sales">200 <i class="i-Speach-Bubble-3"></i></span></div>
				<div class="ul-widget5__stats"><span class="ul-widget5__number">
				<form action="<?php echo e(route('inkubator.destroyBerita', $b->id)); ?>" method="post">
                	<?php echo csrf_field(); ?>
                	<input type="hidden" name="_method" value="DELETE">
					<a class="ul-link-action text-success" href="<?php echo e(route('inkubator.editBerita', $b->id)); ?>" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="i-Edit"></i></a>
					<button type="submit" class="btn btn-link ul-link-action text-danger mr-1" data-toggle="tooltip" data-placement="top" title="" data-original-title="Want To Delete !!!"><i class="i-Eraser-2"></i></button>
				</form>
				</span></div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	<ul class="pagination justify-content-center">
		<li class="page-item"><?php echo e($berita->links()); ?></li>
	</ul>

	</div>
</div>
</div>
</div>
<div class="col-xl-4 col-lg-4">
<div class="card mb-4">
	<div class="card-body">
		<div class="card-title mb-0">Berita Umum</div>
	</div>
	<div class="ul-widget-app__comments">
		<!--  row-comments -->
		<?php $__empty_1 = true; $__currentLoopData = $umum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<div class="ul-widget-app__row-comments">
			<div class="ul-widget-app__profile-pic p-3"><img class="profile-picture avatar-lg" src="<?php echo e(asset('storage/berita/' . $row->foto)); ?>" alt="alt" /></div>
			<div class="ul-widget-app__comment">
				<div class="ul-widget-app__profile-title">
					<a class="ul-widget4__title" href="<?php echo e(route('inkubator.showBerita', $row->slug)); ?>"><?php echo e(Str::limit($row->tittle, 40)); ?></a>
				</div>
				<div class="ul-widget-app__profile-status"><span class="badge badge-pill badge-primary p-2 m-1">Pending</span><span class="ul-widget-app__icons"><a href="href"><i class="i-Approved-Window text-mute"></i></a><a href="href"><i class="i-Like text-mute"></i></a><a href="href"><i class="i-Heart1 text-mute"></i></a></span><span class="text-mute"><?php echo e($row->created_at->format('d, M Y')); ?></span></div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<p class="text-center">Tidak Ada Berita Umum</p>
		<?php endif; ?>
		</div>
		<ul class="pagination justify-content-center">
			<li class="page-item"><?php echo e($berita->links()); ?></li>
		</ul>
	</div>

	<div class="card">
		<div class="card-body">
			<div class="card-title mb-0">Recent Comments</div>
		</div>
		<div class="ul-widget-app__comments">
			<?php $__currentLoopData = $hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $li): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="ul-widget-app__row-comments">
				<div class="ul-widget-app__profile-pic p-3"><img class="profile-picture avatar-md mb-2 rounded-circle" src="<?php echo e(asset('assets/images/images2.jpg')); ?>" alt="alt" /></div>
				<div class="ul-widget-app__comment">
					<div class="ul-widget-app__profile-title">
						<h6 class="heading"><?php echo e($li->name); ?></h6>
						<p class="mb-2"><?php echo e($li->komentar); ?></p>
					</div>
					<div class="ul-widget-app__profile-status">
					<span class="ul-widget-app__icons">
					<!-- <a href="inkubator/berita/destroy/<?php echo e($li->id); ?>" class="badge badge-pill badge-danger p-2 m-1">Delete</a> -->	
					</span>
					<span class="text-mute"><?php echo e(date('d M Y',strtotime($li->created_at))); ?></span>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\siskubis\magang\berita\siskubis\resources\views/berita/index.blade.php ENDPATH**/ ?>