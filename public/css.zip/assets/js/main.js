mediumZoom('.zoom-dark', {
    background: '#000'
})
